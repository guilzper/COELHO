window.onload = function(){

const canvas =
document.getElementById("game");

const ctx =
canvas.getContext("2d");

canvas.width =
window.innerWidth;

canvas.height =
window.innerHeight;

// BOTÃO

const startBtn =
document.getElementById("startBtn");

// ESTADO

let gameStarted = false;

let night = false;

let score = 0;

// PLAYER

const player = {

    x:200,
    y:500,

    width:90,
    height:90,

    velocityY:0,

    jumping:false

};

// OBSTÁCULO

const obstacle = {

    x:1600,
    y:520,

    width:70,
    height:100

};

// COMEÇAR

startBtn.onclick = function(){

    document
    .getElementById("menu")
    .style.display = "none";

    gameStarted = true;

};

// PULO

document.addEventListener("keydown",function(e){

    if(
        e.code === "Space"
        &&
        !player.jumping
    ){

        player.velocityY = -22;

        player.jumping = true;

    }

});

// FUNDO

function drawBackground(){

    if(!night){

        ctx.fillStyle = "#8be9ff";

    }else{

        ctx.fillStyle = "#140028";

    }

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // estrelas

    if(night){

        for(let i=0;i<50;i++){

            ctx.fillStyle = "white";

            ctx.fillRect(

                Math.random()*canvas.width,

                Math.random()*300,

                2,

                2

            );

        }

    }

    // chão

    ctx.fillStyle =
    night
    ?
    "#ff00ff"
    :
    "#66dd66";

    ctx.fillRect(
        0,
        canvas.height - 100,
        canvas.width,
        100
    );

}

// BRILHO

function drawGlow(){

    for(let i=0;i<10;i++){

        ctx.fillStyle =
        "rgba(255,255,255,0.4)";

        ctx.beginPath();

        ctx.arc(

            player.x +
            Math.random()*90,

            player.y +
            Math.random()*90,

            Math.random()*8,

            0,

            Math.PI*2

        );

        ctx.fill();

    }

}

// ARCO ÍRIS

function drawRainbowTrail(){

    const colors = [

        "red",
        "orange",
        "yellow",
        "green",
        "cyan",
        "blue",
        "purple"

    ];

    for(let i=0;i<colors.length;i++){

        ctx.fillStyle = colors[i];

        ctx.fillRect(

            player.x - 50,

            player.y + (i*7),

            50,

            7

        );

    }

}

// PERSONAGEM

function drawPlayer(){

    // COELHO

    if(!night){

        drawGlow();

        ctx.fillStyle = "white";

        ctx.fillRect(
            player.x,
            player.y,
            90,
            90
        );

        // orelhas

        ctx.fillRect(
            player.x + 10,
            player.y - 35,
            15,
            40
        );

        ctx.fillRect(
            player.x + 60,
            player.y - 35,
            15,
            40
        );

        // olho

        ctx.fillStyle = "black";

        ctx.beginPath();

        ctx.arc(
            player.x + 60,
            player.y + 35,
            5,
            0,
            Math.PI*2
        );

        ctx.fill();

    }

    // MORCEGO

    if(night){

        drawRainbowTrail();

        ctx.fillStyle = "#9b4dff";

        ctx.beginPath();

        ctx.arc(
            player.x + 45,
            player.y + 45,
            45,
            0,
            Math.PI*2
        );

        ctx.fill();

        // asas

        ctx.fillRect(
            player.x - 30,
            player.y + 20,
            35,
            15
        );

        ctx.fillRect(
            player.x + 85,
            player.y + 20,
            35,
            15
        );

    }

}

// OBSTÁCULO

function drawObstacle(){

    ctx.fillStyle =
    night
    ?
    "#00ffff"
    :
    "#8B4513";

    ctx.fillRect(
        obstacle.x,
        obstacle.y,
        obstacle.width,
        obstacle.height
    );

}

// SCORE

function drawScore(){

    ctx.fillStyle = "white";

    ctx.font = "35px Arial";

    ctx.fillText(
        "Pontos: " + score,
        30,
        50
    );

}

// UPDATE

function update(){

    requestAnimationFrame(update);

    if(!gameStarted){
        return;
    }

    drawBackground();

    // gravidade

    player.velocityY += 1;

    player.y += player.velocityY;

    // chão

    if(player.y >= 500){

        player.y = 500;

        player.jumping = false;

    }

    // obstáculo

    obstacle.x -= 10;

    if(obstacle.x < -100){

        obstacle.x = 1600;

        score++;

    }

    // noite

    if(score >= 5){

        night = true;

    }

    if(score >= 10){

        night = false;

        score = 0;

    }

    // colisão

    if(

        player.x <
        obstacle.x + obstacle.width

        &&

        player.x + player.width >
        obstacle.x

        &&

        player.y <
        obstacle.y + obstacle.height

        &&

        player.y + player.height >
        obstacle.y

    ){

        alert("GAME OVER");

        obstacle.x = 1600;

        score = 0;

        night = false;

    }

    drawObstacle();

    drawPlayer();

    drawScore();

}

update();

}