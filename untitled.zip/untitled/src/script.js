const canvas =
document.getElementById("game");

const ctx =
canvas.getContext("2d");

canvas.width =
window.innerWidth;

canvas.height =
window.innerHeight;

let selectedCharacter = "lumi";

let gameStarted = false;

const player = {

    x:200,
    y:500,

    width:90,
    height:90,

    velocityY:0,

    jumping:false

};

// selecionar personagem

function selectCharacter(name){

    selectedCharacter = name;

    document
    .getElementById("lumiCard")
    .classList.remove("selected");

    document
    .getElementById("noxCard")
    .classList.remove("selected");

    document
    .getElementById("hammyCard")
    .classList.remove("selected");

    if(name === "lumi"){

        document
        .getElementById("lumiCard")
        .classList.add("selected");

    }

    if(name === "nox"){

        document
        .getElementById("noxCard")
        .classList.add("selected");

    }

    if(name === "hammy"){

        document
        .getElementById("hammyCard")
        .classList.add("selected");

    }

}

// começar

document
.getElementById("startBtn")
.addEventListener("click",()=>{

    document
    .getElementById("menu")
    .style.display = "none";

    gameStarted = true;

});

// pulo

document.addEventListener("keydown",(e)=>{

    if(
        e.code === "Space"
        &&
        !player.jumping
    ){

        player.velocityY = -20;

        player.jumping = true;

    }

});

// fundo

function drawBackground(){

    // fundo gradiente

    const gradient =
    ctx.createLinearGradient(
        0,
        0,
        0,
        canvas.height
    );

    gradient.addColorStop(0,"#220044");
    gradient.addColorStop(1,"#000000");

    ctx.fillStyle = gradient;

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // estrelas

    for(let i = 0; i < 80; i++){

        ctx.fillStyle = "white";

        ctx.fillRect(
            Math.random() * canvas.width,
            Math.random() * canvas.height,
            2,
            2
        );

    }

    // chão

    ctx.fillStyle = "#ff00ff";

    ctx.fillRect(
        0,
        canvas.height - 100,
        canvas.width,
        100
    );

}

// personagem

function drawCharacter(){

    // LUMI

    if(selectedCharacter === "lumi"){

        ctx.fillStyle = "white";

        ctx.beginPath();

        ctx.roundRect(
            player.x,
            player.y,
            90,
            90,
            30
        );

        ctx.fill();

        // orelhas

        ctx.fillRect(
            player.x + 10,
            player.y - 35,
            15,
            40
        );

        ctx.fillRect(
            player.x + 60,
            player.y - 35,
            15,
            40
        );

    }

    // NOX

    if(selectedCharacter === "nox"){

        ctx.fillStyle = "#ff00ff";

        ctx.beginPath();

        ctx.arc(
            player.x + 45,
            player.y + 45,
            45,
            0,
            Math.PI*2
        );

        ctx.fill();

    }

    // HAMMY

    if(selectedCharacter === "hammy"){

        // arco-íris

        const colors = [
            "#ff0000",
            "#ff8800",
            "#ffff00",
            "#00ff00",
            "#00ffff",
            "#0000ff",
            "#ff00ff"
        ];

        for(let i = 0; i < colors.length; i++){

            ctx.fillStyle = colors[i];

            ctx.fillRect(
                player.x - 80,
                player.y + (i * 8),
                80,
                8
            );

        }

        // corpo

        ctx.fillStyle = "#ffd166";

        ctx.beginPath();

        ctx.arc(
            player.x + 45,
            player.y + 45,
            45,
            0,
            Math.PI * 2
        );

        ctx.fill();

        // orelhas

        ctx.fillStyle = "#ffb703";

        ctx.beginPath();

        ctx.arc(
            player.x + 15,
            player.y + 10,
            15,
            0,
            Math.PI * 2
        );

        ctx.fill();

        ctx.beginPath();

        ctx.arc(
            player.x + 75,
            player.y + 10,
            15,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

}

// update

function update(){

    requestAnimationFrame(update);

    if(!gameStarted){
        return;
    }

    drawBackground();

    // gravidade

    player.velocityY += 1;

    player.y += player.velocityY;

    // chão

    if(player.y >= 500){

        player.y = 500;

        player.velocityY = 0;

        player.jumping = false;

    }

    drawCharacter();

}

update();